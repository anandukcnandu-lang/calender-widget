package com.example.mycalendarwidget;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.view.Gravity;
import android.view.ViewGroup;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(32, 48, 32, 32);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        TextView title = new TextView(this);
        title.setText("My Calendar");
        title.setTextSize(26);
        title.setGravity(Gravity.CENTER);
        box.addView(title, new LinearLayout.LayoutParams(-1, -2));
        TextView message = new TextView(this);
        message.setText("Your calendar widget is ready.\n\nTo place it on your home screen:\n1. Long-press an empty area of your home screen.\n2. Choose Widgets.\n3. Find My Calendar.\n4. Drag the large calendar widget onto your home screen.\n5. Resize it if needed.");
        message.setTextSize(17);
        message.setPadding(0, 28, 0, 0);
        box.addView(message, new LinearLayout.LayoutParams(-1, -2));
        setContentView(box);
    }
}
