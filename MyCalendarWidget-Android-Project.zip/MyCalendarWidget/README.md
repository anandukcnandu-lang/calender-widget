# My Calendar Android Widget

A native Android home-screen calendar widget. Tap any date to toggle a strikethrough mark; use ‹ and › to change months. Marks are stored locally and persist across app restarts.

## Build an APK
Open this folder in Android Studio (JDK 17, Android SDK 35), allow Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**. The debug APK is created at `app/build/outputs/apk/debug/app-debug.apk`.

Alternatively, push this project to a GitHub repository and run the **Build Android APK** workflow from the Actions tab. Download the `MyCalendar-debug-apk` artifact.

## Install and add widget
Install the APK on your Android phone. Long-press an empty home-screen area > Widgets > My Calendar, then drag the widget onto the home screen. Resize it to a large 4×5/4×6 area if your launcher allows it.

This project is provided as source; it is not a precompiled APK.
