package com.example.mycalendarwidget;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.ComponentName;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Paint;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.RemoteViews;
import java.time.LocalDate;
import java.time.YearMonth;
import java.time.format.TextStyle;
import java.util.Locale;

public class CalendarWidgetProvider extends AppWidgetProvider {
    private static final String PREFS = "calendar_widget_data";
    private static final String ACTION_TOGGLE = "com.example.mycalendarwidget.TOGGLE";
    private static final String ACTION_PREV = "com.example.mycalendarwidget.PREV";
    private static final String ACTION_NEXT = "com.example.mycalendarwidget.NEXT";
    private static final String ACTION_TODAY = "com.example.mycalendarwidget.TODAY";
    private static final int BLUE = Color.rgb(48, 91, 145);
    private static final int TEXT = Color.rgb(35, 38, 43);
    private static final int MUTED = Color.rgb(115, 120, 128);
    private static final int LINE = Color.rgb(220, 224, 230);
    private static final int MARKED_BG = Color.rgb(226, 235, 247);

    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) updateOne(context, manager, id);
    }

    @Override public void onReceive(Context context, Intent intent) {
        super.onReceive(context, intent);
        String action = intent.getAction();
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        if (ACTION_TOGGLE.equals(action)) {
            String date = intent.getStringExtra("date");
            if (date != null) {
                boolean old = prefs.getBoolean("mark_" + date, false);
                prefs.edit().putBoolean("mark_" + date, !old).apply();
            }
        } else if (ACTION_PREV.equals(action) || ACTION_NEXT.equals(action) || ACTION_TODAY.equals(action)) {
            LocalDate shown = LocalDate.ofEpochDay(prefs.getLong("shown_month", LocalDate.now().withDayOfMonth(1).toEpochDay()));
            if (ACTION_PREV.equals(action)) shown = shown.minusMonths(1);
            else if (ACTION_NEXT.equals(action)) shown = shown.plusMonths(1);
            else shown = LocalDate.now().withDayOfMonth(1);
            prefs.edit().putLong("shown_month", shown.withDayOfMonth(1).toEpochDay()).apply();
        }
        if (ACTION_TOGGLE.equals(action) || ACTION_PREV.equals(action) || ACTION_NEXT.equals(action) || ACTION_TODAY.equals(action)) {
            AppWidgetManager manager = AppWidgetManager.getInstance(context);
            int[] ids = manager.getAppWidgetIds(new ComponentName(context, CalendarWidgetProvider.class));
            onUpdate(context, manager, ids);
        }
    }

    private static PendingIntent broadcast(Context c, String action, int request, String date) {
        Intent i = new Intent(c, CalendarWidgetProvider.class).setAction(action);
        if (date != null) i.putExtra("date", date);
        return PendingIntent.getBroadcast(c, request, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }

    private void updateOne(Context context, AppWidgetManager manager, int widgetId) {
        SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        long initial = LocalDate.now().withDayOfMonth(1).toEpochDay();
        LocalDate first = LocalDate.ofEpochDay(prefs.getLong("shown_month", initial)).withDayOfMonth(1);
        YearMonth ym = YearMonth.from(first);
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.calendar_widget);
        String monthName = first.getMonth().getDisplayName(TextStyle.FULL, Locale.getDefault());
        views.setTextViewText(R.id.month_title, monthName + " " + first.getYear());
        views.setOnClickPendingIntent(R.id.prev_button, broadcast(context, ACTION_PREV, 1001, null));
        views.setOnClickPendingIntent(R.id.next_button, broadcast(context, ACTION_NEXT, 1002, null));
        views.setOnClickPendingIntent(R.id.today_button, broadcast(context, ACTION_TODAY, 1003, null));

        int offset = first.getDayOfWeek().getValue() % 7; // Sunday = 0
        int days = ym.lengthOfMonth();
        int totalCells = ((offset + days + 6) / 7) * 7;
        String[] weekdays = {"S", "M", "T", "W", "T", "F", "S"};
        for (int col = 0; col < 7; col++) {
            RemoteViews label = new RemoteViews(context.getPackageName(), R.layout.weekday_cell);
            label.setTextViewText(R.id.weekday_text, weekdays[col]);
            views.addView(R.id.weekday_row, label);
        }
        int todayDay = LocalDate.now().getDayOfMonth();
        boolean sameMonth = LocalDate.now().getYear() == first.getYear() && LocalDate.now().getMonthValue() == first.getMonthValue();

        for (int row = 0; row < totalCells / 7; row++) {
            RemoteViews rowView = new RemoteViews(context.getPackageName(), R.layout.calendar_row);
            for (int col = 0; col < 7; col++) {
                int cell = row * 7 + col;
                int day = cell - offset + 1;
                RemoteViews cellView = new RemoteViews(context.getPackageName(), R.layout.day_cell);
                if (day < 1 || day > days) {
                    cellView.setTextViewText(R.id.day_text, "");
                    cellView.setInt(R.id.day_text, "setBackgroundColor", Color.TRANSPARENT);
                } else {
                    LocalDate date = first.withDayOfMonth(day);
                    String dateKey = date.toString();
                    boolean marked = prefs.getBoolean("mark_" + dateKey, false);
                    cellView.setTextViewText(R.id.day_text, String.valueOf(day));
                    cellView.setTextColor(R.id.day_text, marked ? BLUE : TEXT);
                    cellView.setInt(R.id.day_text, "setBackgroundColor", marked ? MARKED_BG : Color.TRANSPARENT);
                    cellView.setInt(R.id.day_text, "setPaintFlags", marked ? Paint.STRIKE_THRU_TEXT_FLAG : 0);
                    if (sameMonth && day == todayDay) {
                        cellView.setTextColor(R.id.day_text, BLUE);
                        cellView.setInt(R.id.day_text, "setBackgroundResource", R.drawable.today_border);
                    }
                    cellView.setOnClickPendingIntent(R.id.day_text,
                        broadcast(context, ACTION_TOGGLE, 2000 + dateKey.hashCode(), dateKey));
                }
                rowView.addView(R.id.calendar_row, cellView);
            }
            views.addView(R.id.days_container, rowView);
        }
        manager.updateAppWidget(widgetId, views);
    }
}
